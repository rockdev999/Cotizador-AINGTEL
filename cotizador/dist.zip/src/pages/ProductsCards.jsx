import React, { useState } from "react";
import { products } from "../data";

function ProductCards() {
  const [productList, setProductList] = useState(products);

  return (
    <div className="p-8 bg-gray-100">
      <h2 className="text-2xl font-bold text-center mb-4">Productos</h2>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
        {productList.map((product) => (
          <div
            key={product.id}
            className="relative bg-white border border-black rounded-lg shadow-lg p-4"
          >
            {/* Contenedor de la imagen con un tamaño ajustado */}
            <div className="w-full h-24 mb-4 flex items-center justify-center">
              <img
                src={product.image}
                alt={product.name}
                className="max-w-full max-h-full object-contain rounded-md"
              />
            </div>

            {/* Información del producto */}
            <h3 className="text-lg font-semibold text-gray-800">
              {product.name}
            </h3>
            <p className="text-sm text-gray-600">{product.category}</p>

            {/* Sección adicional para detalles */}
            <div className="mt-2 text-gray-500 text-xs"></div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ProductCards;
