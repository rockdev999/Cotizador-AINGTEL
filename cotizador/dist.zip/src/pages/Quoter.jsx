import React, { useState, useEffect } from "react";
import axios from "axios";

const Quoter = () => {
  const [categorias, setCategorias] = useState([]);
  const [productos, setProductos] = useState([]);
  const [productosEjemplo, setProductosEjemplo] = useState([]);
  const [categoriaSeleccionada, setCategoriaSeleccionada] = useState(0);
  const [productoSeleccionado, setProductoSeleccionado] = useState(null);
  const [cantidad, setCantidad] = useState(1);
  const [precioTotal, setPrecioTotal] = useState(0.0);
  const [listaProductos, setListaProductos] = useState([]);

  // Simulación de datos (reemplaza esto con una llamada a tu API)
  useEffect(() => {
    axios
      .get("http://localhost:3000/categories")
      .then((result) => {
        setCategorias(result.data);
        console.log(result.data);
      })
      .catch((error) => console.log(error));
  }, []);

  useEffect(() => {
    if (categoriaSeleccionada) {
      // Simulación de productos por categoría (reemplaza esto con una llamada a tu API)
      axios
        .get("http://localhost:3000/products")
        .then((result) => {
          setProductosEjemplo(result.data);
          // console.log("adsasd");
          // console.log(productosEjemplo);
        })
        .catch((error) => console.log(error));
      setProductos(
        productosEjemplo.filter(
          (p) => p.category === parseInt(categoriaSeleccionada)
        )
      );
    } else {
      setProductos([]);
    }
  }, [categoriaSeleccionada]);

  const handleAgregarProducto = () => {
    if (productoSeleccionado && cantidad > 0) {
      const productoConCantidad = {
        ...productoSeleccionado,
        cantidad,
        precioTotal: productoSeleccionado.price * cantidad,
      };
      setListaProductos([...listaProductos, productoConCantidad]);
      setCantidad(1); // Reiniciar cantidad
    }
  };

  const handleEliminarProducto = (code) => {
    setListaProductos(listaProductos.filter((prod) => prod.code !== code));
  };

  return (
    <div className="pt-20">
      <div
        className="pt-20 bg-orange-500"
        style={{ padding: "40px", maxWidth: "600px", margin: "0 auto" }}
      >
        <h2>Cotización de Productos</h2>

        {/* Desplegable de categorías */}
        <label htmlFor="categoria">Categoría:</label>
        <select
          id="categoria"
          value={categoriaSeleccionada}
          onChange={(e) => setCategoriaSeleccionada(e.target.value)}
          style={{ display: "block", marginBottom: "10px", width: "100%" }}
        >
          {categorias.map((cat) => (
            <option key={cat.id} value={cat.id}>
              {cat.name}
            </option>
          ))}
        </select>

        {/* Desplegable de productos */}
        <label htmlFor="producto">Producto:</label>
        <select
          id="producto"
          value={productoSeleccionado ? productoSeleccionado.code : ""}
          onChange={(e) => {
            const producto = productos.find((p) => p.code === e.target.value);
            setProductoSeleccionado(producto);
            if (producto) setPrecioTotal(producto.price * cantidad);
          }}
          style={{ display: "block", marginBottom: "10px", width: "100%" }}
        >
          <option value="">Seleccione un producto</option>
          {productos.map((prod) => (
            <option key={prod.code} value={prod.code}>
              {prod.name}
            </option>
          ))}
        </select>

        {/* Input de cantidad */}
        <label htmlFor="cantidad">Cantidad:</label>
        <input
          type="number"
          id="cantidad"
          value={cantidad}
          onChange={(e) => {
            setCantidad(parseInt(e.target.value) || 1);
            if (productoSeleccionado) {
              setPrecioTotal(
                productoSeleccionado.price * (parseInt(e.target.value) || 1)
              );
            }
          }}
          style={{ display: "block", marginBottom: "10px", width: "100%" }}
          min="1"
        />

        {/* Mostrar precio total */}
        <p>Precio Total: ${precioTotal}</p>

        {/* Botón de agregar */}
        <button
          onClick={handleAgregarProducto}
          style={{ display: "block", marginBottom: "20px" }}
        >
          Agregar Producto
        </button>

        {/* Lista de productos agregados */}
        <h3>Productos Agregados</h3>
        <ul>
          {listaProductos.map((prod) => (
            <li key={prod.code} style={{ marginBottom: "10px" }}>
              {prod.name} - Cantidad: {prod.cantidad} - Precio Total: $
              {prod.precioTotal}
              <button
                onClick={() => handleEliminarProducto(prod.code)}
                style={{ marginLeft: "10px" }}
              >
                X
              </button>
            </li>
          ))}
        </ul>
        <div>
          <input type="number" />
        </div>
      </div>
    </div>
  );
};

export default Quoter;
