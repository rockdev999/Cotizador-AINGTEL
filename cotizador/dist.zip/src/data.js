// actualizado
export const dealers = [
  {
    ci: 12345678,
    name: "Rodrigo Quispe Mendoza",
    email: "rodrigo@example.com",
    password: "mipass123",
    phone: 7316565,
    address: "San Pedro",
  },
  {
    ci: 9876543,
    name: "Raul Salazar Conde",
    email: "raul@example.com",
    password: "mipass123",
    phone: 69825314,
    address: "Tembladerani",
  },
  {
    ci: 74582364,
    name: "Aime Caceres Cabrera",
    email: "aime@example.com",
    password: "mipass123",
    phone: 61247834,
    address: "Pampahasi",
  },
];

export const products = [
  {
    id: 1,
    name: "Camara",
    cost: 18,
    price: 25,
    image: "product-1.jpeg",
    code: "abc123",
    category: 1,
    desciption: "aqui esta la descripcion del producto",
  },
  {
    id: 2,
    name: "Product 2",
    cost: 18,
    price: 25,
    image: "product-2.jpeg",
    code: "abc1234",
    category: 2,
    desciption: "aqui esta la descripcion del producto",
  },
  {
    id: 3,
    name: "Product 3",
    cost: 18,
    price: 25,
    image: "product-3.jpeg",
    code: "abc1235",
    category: 3,
    desciption: "aqui esta la descripcion del producto",
  },
  {
    id: 4,
    name: "Product 4",
    cost: 18,
    price: 25,
    image: "product-4.jpeg",
    code: "abc1236",
    category: 4,
    desciption: "aqui esta la descripcion del producto",
  },
  {
    id: 5,
    name: "Product 5",
    cost: 18,
    price: 25,
    image: "product-5.jpeg",
    code: "abc1237",
    category: 5,
    desciption: "aqui esta la descripcion del producto",
  },
];
//actualizado
export const users = [
  {
    email: "juan.perez@example.com",
    password: "password123",
    rol: "admin",
  },

  {
    email: "maria.garcia@example.com",
    password: "securePass456",
    rol: "dealer",
  },

  {
    email: "carlos.lopez@example.com",
    password: "mySecret789",
    rol: "dealer",
  },
];

export const categories = [
  { id: 1, name: "Categoría" },
  { id: 2, name: "Videovigilancia" },
  { id: 3, name: "Redes y Comunicaciones" },
  { id: 4, name: "Seguridad Electrónica" },
  { id: 5, name: "Sistemas Domóticos" },
  { id: 6, name: "Sistemas para Energía y Respaldo" },
  { id: 7, name: "Biométricos" },
  { id: 8, name: "Sistemas Eléctricos" },
];
