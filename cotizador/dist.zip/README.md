# Cotizador-AINGTEL
Sistema Web que cotiza productos de la empresa AINGTEL, la empresa se dedica a vender productos vigilancia, redes y comunicaciones, seguridad  electronica, sistemas domoticos, sistemas para energia y respaldo, biometricos y sistemas electricos
